//-----------------------------------------------------------------------------
// Copyright (c) 2006-2007 dhpoware. All rights reserved.

#include <GL/gl.h>
#include <GL/glu.h>



#ifdef WIN32
      
      
      #include "cpp/WGL_ARB_multisample.h"
#endif




