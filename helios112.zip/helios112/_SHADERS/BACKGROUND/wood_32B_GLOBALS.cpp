
                                      
                                  //=====================================================================================|_SHADER
                                  GLuint      wood_32B_SHADER_VERTEX;                                                                                 
                                  GLuint      wood_32B_SHADER_FRAGMENT;                                                                               
                                  GLuint      wood_32B_SHADER;     
                                  //-------------------------------------------------------------------------------------|_CONFIGURABLE_UNIFORMS
                                  GLuint      UNIFORM_LIGHT_POSITION_01_wood_32B;                                                                     
                                  GLuint      UNIFORM_ambient_wood_32B;
                                  GLuint      UNIFORM_counter_wood_32B;                                                                               
                                  //-------------------------------------------------------------------------------------|_CORRECTION_UNIFORMS
                                  GLuint      UNIFORM_offset_wood_32B;                                                                                
                                  GLuint      UNIFORM_tileJump_wood_32B;                                                                              
                                  //-------------------------------------------------------------------------------------|_MATRIX_UNIFORMS
                                  GLuint      UNIFORM_MODELVIEW_wood_32B;                                                                             
                                  GLuint      UNIFORM_MODELVIEWPROJ_wood_32B;                                                                         
                                  //GLuint    UNIFORM_MODELVIEWPROJ_INVERSE_wood_32B;                                                                 
                                  GLuint      UNIFORM_LIGHT_MATRIX_wood_32B;                                                                          
                                  GLuint      UNIFORM_TEXTURE_MATRIX_wood_32B;                                                                        
                                  //-------------------------------------------------------------------------------------|_TEXTURE_UNIFORMS
                                  GLuint      UNIFORM_TEXTURE_SHADOW_wood_32B;                                                                        
                                  GLuint      UNIFORM_TEXTURE_DOT3_wood_32B;                                                                          
                                  GLuint      UNIFORM_TEXTURE_wood_32B; 
