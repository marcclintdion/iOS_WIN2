                             GLuint      SHADER_VERTEX_shadow;
                             GLuint      SHADER_FRAGMENT_shadow;
                             GLuint      SHADER_shadow;
                             //-------------------------------------- 
                             GLuint      UNIFORM_darkness_shadow;
                             GLuint      UNIFORM_MODELVIEW_shadow;                             
                             GLuint      UNIFORM_MODELVIEWPROJ_shadow;
                             GLuint      UNIFORM_MODELVIEWPROJ_INVERSE_shadow;
                             GLuint      UNIFORM_LIGHT_MATRIX_shadow;
                             //--------------------------------------------------------      
