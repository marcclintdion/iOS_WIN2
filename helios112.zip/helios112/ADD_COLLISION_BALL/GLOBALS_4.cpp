GLfloat     lightPos_spikyBall_00_4[]  = {26.75, 102.93, -50.96};
GLfloat     lightPos_spikes_00_4[]           =  {2.3176, 8.895, 14.04};
GLfloat     lightAttenuation_spikes_00_4     =   3.38642;              
GLfloat     lightAttenuation_spikyBall_00_4   =  1.283;
GLfloat     spikyBall_00_4_position[]  = {0.5, 0.5, 0.5};
GLfloat     spinBall_4             =  0.0;
GLfloat     spinVelocity_4             =  1.0;
GLfloat     radius_4             =  0.125;
GLfloat     spikyBall_00_4_Velocity[]  = {0.01, -0.004, -0.03};
GLfloat     spinX_Ball_4             = 0.0;
GLfloat     spinZ_Ball_4             = 0.0;
GLfloat     velocityIncreaseRotation_4     = 1.0;                  
GLfloat     velocitySwap_4[]               = {0.0, 0.0, 0.0, 0.0}; 
//----------                                               
GLfloat     flyingSpikyBallShadowPosition_00_4[] =  {-0.05, 0.27, -11.4};
GLfloat     flyingSpikyBallShadowRotation_00_4[] =  { 1.0, 1.0, 1.0, 0.0};
GLfloat     scaleFlyingSpikyBallShadow_00_4         = 1.2;              
//----------
GLfloat     flyingSpikyBallShadowPosition_01_4[] =   {0.198, 0.470997, -11.7171};
GLfloat     flyingSpikyBallShadowRotation_01_4[] =  { 1.0, 1.0, 1.0, 0.0};
GLfloat     scaleFlyingSpikyBallShadow_01_4      =    1.5;               
//``````````````````````````````````````````````

GLfloat     distance_4_1=  0.0;
GLfloat     distance_4_2=  0.0;
GLfloat     distance_4_3=  0.0;
//``````````````````````````````````````````````
///////=========================================================   
GLfloat     SWIZZLE_Velocity_4_1[]       = {0.0, 0.0, 0.0};
GLfloat     SWIZZLE_Velocity_4_2[]       = {0.0, 0.0, 0.0};
GLfloat     SWIZZLE_Velocity_4_3[]       = {0.0, 0.0, 0.0};
///////=========================================================   
/////////----------------------------------------------   
GLfloat     spikyBall_00_4_1_vector[]       = {0.0, 0.0, 0.0};
GLfloat     spikyBall_00_4_2_vector[]       = {0.0, 0.0, 0.0};
GLfloat     spikyBall_00_4_3_vector[]       = {0.0, 0.0, 0.0};
/////////----------------------------------------------   
////------------------////
bool collision_4_1        = false;
bool collision_4_2        = false;
bool collision_4_3        = false;
////------------------////
