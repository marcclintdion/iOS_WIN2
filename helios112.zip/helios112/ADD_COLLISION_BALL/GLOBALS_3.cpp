GLfloat     lightPos_spikyBall_00_3[]  = {26.75, 102.93, -50.96};
GLfloat     lightAttenuation_spikyBall_00_3   =  1.283;
GLfloat     spikyBall_00_3_position[]  = {0.5, 0.5, 0.5};
GLfloat     spinBall_3             =  0.0;
GLfloat     spinVelocity_3             =  1.0;
GLfloat     radius_3             =  0.125;
GLfloat     spikyBall_00_3_Velocity[]  = {0.01, 0.012, 0.01};
GLfloat     spinX_Ball_3             = 0.0;
GLfloat     spinZ_Ball_3             = 0.0;
//----------                                               
GLfloat     flyingSpikyBallShadowPosition_00_3[] =  {-0.05, 0.27, -11.4};
GLfloat     flyingSpikyBallShadowRotation_00_3[] =  { 1.0, 1.0, 1.0, 0.0};
GLfloat     scaleFlyingSpikyBallShadow_00_3         = 1.2;              
//----------
GLfloat     flyingSpikyBallShadowPosition_01_3[] =   {0.198, 0.470997, -11.7171};
GLfloat     flyingSpikyBallShadowRotation_01_3[] =  { 1.0, 1.0, 1.0, 0.0};
GLfloat     scaleFlyingSpikyBallShadow_01_3      =    1.5;               
//``````````````````````````````````````````````

GLfloat     distance_3_1=  0.0;
GLfloat     distance_3_2=  0.0;
//``````````````````````````````````````````````
///////=========================================================   
GLfloat     SWIZZLE_Velocity_3_1[]       = {0.0, 0.0, 0.0};
GLfloat     SWIZZLE_Velocity_3_2[]       = {0.0, 0.0, 0.0};
///////=========================================================   
/////////----------------------------------------------   
GLfloat     spikyBall_00_3_1_vector[]       = {0.0, 0.0, 0.0};
GLfloat     spikyBall_00_3_2_vector[]       = {0.0, 0.0, 0.0};
/////////----------------------------------------------   
////------------------////
bool collision_3_1        = false;
bool collision_3_2        = false;
////------------------////
