GLfloat     lightPos_spikyBall_00_2[]  = {26.75, 102.93, -50.96};
GLfloat     lightAttenuation_spikyBall_00_2   =  1.283;
GLfloat     spikyBall_00_2_position[]  = {0.5, 0.5, 0.5};
GLfloat     spinBall_2             =  0.0;
GLfloat     radius_2             =  0.125;
GLfloat     spikyBall_00_2_Velocity[]  = {0.041, 0.017, 0.034};
GLfloat     spinX_Ball_2             = 0.0;
GLfloat     spinZ_Ball_2             = 0.0;
//----------                                               
GLfloat     flyingSpikyBallShadowPosition_00_2[] =  {-0.05, 0.27, -11.4};
GLfloat     flyingSpikyBallShadowRotation_00_2[] =  { 1.0, 1.0, 1.0, 0.0};
GLfloat     scaleFlyingSpikyBallShadow_00_2         = 1.2;              
//----------
GLfloat     flyingSpikyBallShadowPosition_01_2[] =   {0.198, 0.470997, -11.7171};
GLfloat     flyingSpikyBallShadowRotation_01_2[] =  { 1.0, 1.0, 1.0, 0.0};
GLfloat     scaleFlyingSpikyBallShadow_01_2      =    1.5;               
//``````````````````````````````````````````````

GLfloat     distance_2_1=  0.0;
//``````````````````````````````````````````````
///////=========================================================   
GLfloat     SWIZZLE_Velocity_2_1[]       = {0.0, 0.0, 0.0};
///////=========================================================   
/////////----------------------------------------------   
GLfloat     spikyBall_00_2_1_vector[]       = {0.0, 0.0, 0.0};
/////////----------------------------------------------   
////------------------////
bool collision_2_1        = false;
////------------------////
