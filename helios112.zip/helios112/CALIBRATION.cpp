  GLfloat     moveShadow_A[] = {-6.02503, -7.28592, -12.7902, 1};
  GLfloat     head_ATTENUATION         =  0.94;
  GLfloat     head_SHININESS           =  80;
