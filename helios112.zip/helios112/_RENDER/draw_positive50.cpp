      
      //########################################################################
        goldenSunset_LIGHT_POSITION_01[0]                            =  -0.068917;  
        goldenSunset_LIGHT_POSITION_01[1]                            =   3.9; 
        goldenSunset_LIGHT_POSITION_01[2]                            =   500.0;
      //########################################################################

tile_2m_POSITION[0] =   50.0;
tile_2m_POSITION[1] =    -1.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------
tile_2m_POSITION[0] =   50.0;
tile_2m_POSITION[1] =    1.0;
tile_2m_POSITION[2] =    1.0;
//--------------------------
tile_2m_ROTATE[0]   =    1.0; 
tile_2m_ROTATE[1]   =    0.0; 
tile_2m_ROTATE[2]   =    0.0; 
tile_2m_ROTATE[3]   =   90.0; 
//--------------------------
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp"
//---------------------------------------------------

      
      //########################################################################      
        goldenSunset_LIGHT_POSITION_01[0]                            =  -0.068917;  
        goldenSunset_LIGHT_POSITION_01[1]                            =   3.9; 
        goldenSunset_LIGHT_POSITION_01[2]                            =  -0.715183;
      //########################################################################
tile_2m_POSITION[0] =  50.0;
tile_2m_POSITION[1] =   2.0;
tile_2m_POSITION[2] =  -0.0;
//--------------------------
tile_2m_ROTATE[0]   =  0.0; 
tile_2m_ROTATE[1]   =  0.0; 
tile_2m_ROTATE[2]   =  1.0; 
tile_2m_ROTATE[3]   =  0.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------- 
tile_2m_POSITION[0] =  50.0;
tile_2m_POSITION[1] =   2.0;
tile_2m_POSITION[2] =  -2.0;
//--------------------------
tile_2m_ROTATE[0]   =  0.0; 
tile_2m_ROTATE[1]   =  0.0; 
tile_2m_ROTATE[2]   =  1.0; 
tile_2m_ROTATE[3]   =  0.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------- 
tile_2m_POSITION[0] =  50.0;
tile_2m_POSITION[1] =   2.0;
tile_2m_POSITION[2] =  -4.0;
//--------------------------
tile_2m_ROTATE[0]   =  0.0; 
tile_2m_ROTATE[1]   =  0.0; 
tile_2m_ROTATE[2]   =  1.0; 
tile_2m_ROTATE[3]   =  0.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
//--------------------------------------------------- 
tile_2m_POSITION[0] =  50.0;
tile_2m_POSITION[1] =   2.0;
tile_2m_POSITION[2] =  -6.0;
//--------------------------
tile_2m_ROTATE[0]   =  0.0; 
tile_2m_ROTATE[1]   =  0.0; 
tile_2m_ROTATE[2]   =  1.0; 
tile_2m_ROTATE[3]   =  0.0; 
#include "../_MODEL_FOLDERS_/tile_2m/tile_2m_Render.cpp" 
backWall_2x2_POSITION[0] =  50.0;                                                                                                 
backWall_2x2_POSITION[1] =  3.0;                                                                                                 
backWall_2x2_POSITION[2] =  -7.0; 
//-------------------------------
backWall_2x2_ROTATE[0]   =   0.0; 
backWall_2x2_ROTATE[1]   =   0.0; 
backWall_2x2_ROTATE[2]   =   1.0; 
backWall_2x2_ROTATE[3]   =   0.0;     
#include "../_MODEL_FOLDERS_/backWall_2x2/backWall_2x2_Render.cpp" 
//--------------------------------------------------------------  
