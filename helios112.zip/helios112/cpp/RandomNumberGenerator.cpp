
int x,y; 

x = rand()%800;
y = rand()%600;

