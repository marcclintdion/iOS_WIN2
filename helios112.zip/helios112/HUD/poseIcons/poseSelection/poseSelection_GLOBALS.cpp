        
       

        GLfloat         POSITION_ICON_SCALE = 20.0;        
        //--------------
        GLfloat         POSITION_ICON_GLOBAL[]    = {0.058,             0.093,                        -6.0,  0.0};
        //--------------
        GLfloat         POSITION_ICON_01[]        = {1.144747,            1.853496                         -0.0,  0.0};  
        GLfloat         POSITION_ICON_02[]        = {1.149198,           .848431,                     -0.0,  0.0};        
        GLfloat         POSITION_ICON_03[]        = {1.149198,          -0.1515,                     -0.0,  0.0};  
        
        GLfloat         POSITION_ICON_04[]        = {.145898,           1.850851,                     -0.0,  0.0};  
        GLfloat         POSITION_ICON_05[]        = {.145898,           .848431,                     -0.0,  0.0};    
        GLfloat         POSITION_ICON_06[]        = {.145898,           -0.1515,                     -0.0,  0.0};  
        
        GLfloat         POSITION_ICON_07[]        = {-0.853404,           1.854275,                     -0.0,  0.0};  
        GLfloat         POSITION_ICON_08[]        = {-0.853404,           .848431,                     -0.0,  0.0};  
        GLfloat         POSITION_ICON_09[]        = {-0.853404,           -0.1515,                     -0.0,  0.0};  


        GLfloat         armsBackTiltedIn_LIGHT_POSITION_01[]          = { 0.0,  .0,  -2.0,  1.0};  
        //===========================================================================================================================
        GLuint          Z_BLUE_POSITIVE_NORMAL_TEX;     
        //--------------------------------------------------------------
        
        GLuint          armsForwardShouldersBack_TEXTURE1;
        GLuint          armsUpShouldersFarBack_TEXTURE1;
        GLuint          armsOutShouldersBack_TEXTURE1;        
        GLuint          armsBackTiltedIn_TEXTURE1;       
        GLuint          armsOutShouldersForward_TEXTURE1;







