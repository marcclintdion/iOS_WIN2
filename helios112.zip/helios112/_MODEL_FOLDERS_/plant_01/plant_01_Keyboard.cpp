    //---------------------------------------------------------                                                                   
    if (keys['J'])                                                                                                                
    {                                                                                                                             
             moveModel[0]         -=  .01;                                                                                        
    }	                                                                                                                            
    if (keys['L'])                                                                                                                
    {	                                                                                                                            
             moveModel[0]         +=  .01;                                                                                        
    }                                                                                                                             
    if (keys['I'])                                                                                                                
    {	                                                                                                                            
             moveModel[1]         +=  .01;                                                                                        
    }	                                                                                                                            
    if (keys['K'])                                                                                                                
    {	                                                                                                                            
             moveModel[1]         -=  .01;                                                                                        
    }                                                                                                                             
    if (keys['O'])                                                                                                                
    {	                                                                                                                            
             moveModel[2]         +=  .01;                                                                                        
    }	                                                                                                                            
    if (keys['U'])                                                                                                                
    {	                                                                                                                            
             moveModel[2]         -=  .01;                                                                                        
    }                                                                                                                             
