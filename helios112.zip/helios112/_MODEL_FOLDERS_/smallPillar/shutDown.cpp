        glDeleteTextures( 1,    &smallPillar_TEXTURE1);                                                                             
        glDeleteTextures( 1,    &smallPillar_NORMAL_TEX);                                                                           
        glDeleteBuffersARB(1,   &smallPillar_VBO);                                                                                  
        glDeleteProgram(         smallPillar_SHADER);                                                                               
