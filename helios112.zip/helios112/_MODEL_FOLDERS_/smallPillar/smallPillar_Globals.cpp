    GLfloat     smallPillar_POSITION[]               = { 0.0,  0.0,  0.0,  1.0};                                           
    GLfloat     smallPillar_ROTATE[]                 = { 1.0,  0.0,  0.0,  0.0};                                           
    //GLfloat     smallPillar_SCALE[]                  = { 1.0,  1.0,  1.0,  1.0};                                           
    //-----------------------------                                             
    GLuint      smallPillar_VBO;                                                                                           
    //-----------------------------                                                                                        
    GLuint      smallPillar_NORMAL_TEX;                                                                                    
    GLuint      smallPillar_TEXTURE1;                                                                                      

