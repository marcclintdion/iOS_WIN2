#include "_MODEL_FOLDERS_/smallPillar/smallPillar_Globals.cpp"                                                            
#include "_MODEL_FOLDERS_/smallPillar/smallPillar_Init.cpp"                                                               
#include "_MODEL_FOLDERS_/smallPillar/smallPillar_Render.cpp"                                                             

#include "_MODEL_FOLDERS_/smallPillar/shutDown.cpp"                                                                       

#include "_MODEL_FOLDERS_/smallPillar/smallPillar_Shadow_00.cpp"                                                          
#include "_MODEL_FOLDERS_/smallPillar/smallPillar_Shadow_01.cpp"                                                          

