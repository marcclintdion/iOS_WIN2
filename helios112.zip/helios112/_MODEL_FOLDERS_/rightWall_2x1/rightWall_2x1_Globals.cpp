GLfloat     rightWall_2x1_POSITION[]        = { 0.0, 0.0, 0.0, 1.0};                                                                          
GLfloat     rightWall_2x1_ROTATE[]          = { 1.0, 0.0,  0.0, 0.0};                                                                         
GLfloat     rightWall_2x1_SCALE[]           = { 1.0, 0.0,  0.0, 0.0};                                                                         
//-----------------------------------------------------------------                                                                      
GLfloat     rightWall_2x1_LIGHT_POSITION[]  = { 1.0, 5.0, 2.0, 1.0};                                                                          
GLfloat     rightWall_2x1_AMBIENT           = 0.0;                                                                                            
//-----------------------------------------------------------------                                                                      
GLuint      rightWall_2x1_VBO;                                                                                                                
//-----------------------------------------------------------------                                                                      
GLuint      rightWall_2x1_NORMAL_TEX;                                                                                                         
GLuint      rightWall_2x1_TEXTURE1;                                                                                                           
