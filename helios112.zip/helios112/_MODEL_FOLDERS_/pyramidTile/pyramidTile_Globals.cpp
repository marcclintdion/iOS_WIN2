    
    
    GLfloat     pyramidTile_POSITION[]               = { 0.0,  0.0,  0.0,  1.0};                                           
    GLfloat     pyramidTile_ROTATE[]                 = { 1.0,  0.0,  0.0,  0.0};                                           
    //GLfloat     pyramidTile_SCALE[]                  = { 1.0,  1.0,  1.0,  1.0};                                           
    //-----------------------------                                             
    GLuint      pyramidTile_VBO;                                                                                           
    //-----------------------------                                                                                        
    GLuint      pyramidTile_NORMAL_TEX;                                                                                    
    GLuint      pyramidTile_TEXTURE1;                                                                                      

