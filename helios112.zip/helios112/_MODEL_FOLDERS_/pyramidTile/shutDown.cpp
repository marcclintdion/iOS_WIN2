        glDeleteTextures( 1,    &pyramidTile_TEXTURE1);                                                                             
        glDeleteTextures( 1,    &pyramidTile_NORMAL_TEX);                                                                           
        glDeleteBuffersARB(1,   &pyramidTile_VBO);                                                                                  
                                                                              
