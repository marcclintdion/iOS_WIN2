                                                                     
GLfloat     backDrop_ROTATE[]          = { 1.0, 0.0,  0.0, 0.0};                                                                         
GLfloat     backDrop_SCALE[]           = { 1.0, 0.0,  0.0, 0.0};                                                                         
//-----------------------------------------------------------------                                                                      
GLfloat     backDrop_LIGHT_POSITION[]  = { 1.0, 5.0, 2.0, 1.0};                                                                          
GLfloat     backDrop_AMBIENT           = 0.0;                                                                                            
//-----------------------------------------------------------------                                                                      
GLuint      backDrop_VBO;                                                                                                                
//-----------------------------------------------------------------                                                                      
GLuint      backDrop_NORMAL_TEX;                                                                                                         
GLuint      backDrop_TEXTURE1;                                                                                                           
