//====================================================================================                                          
#include "_MODEL_FOLDERS_/springCore/springCore_Globals.cpp"                                                                
//====================================================================================                                          
#include "_MODEL_FOLDERS_/springCore/springCore_Init.cpp"                                                                   
//====================================================================================                                          
#include "_MODEL_FOLDERS_/springCore/springCore_Shadow_01.cpp"                                                              
//====================================================================================                                          
#include "_MODEL_FOLDERS_/springCore/springCore_Shadow_00.cpp"                                                              
//====================================================================================                                          
#include "_MODEL_FOLDERS_/springCore/springCore_Render.cpp"                                                                 
//====================================================================================                                          
#include "_MODEL_FOLDERS_/springCore/springCore_Keyboard.cpp"                                                               
//====================================================================================                                          
#include "_MODEL_FOLDERS_/springCore/springCore_Shutdown.cpp"                                                               
//====================================================================================                                          
