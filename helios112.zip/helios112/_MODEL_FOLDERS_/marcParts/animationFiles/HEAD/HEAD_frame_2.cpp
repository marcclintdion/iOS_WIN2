      
          
      if(setSelection_HEAD == 2)
      {
                   
                      head_ROTATE_FRAMEA[3]   =  head_SET_02[3]     ;
                      head_ROTATE_FRAMEA[0]   =  head_SET_02[0]     ;
                      head_ROTATE_FRAMEA[1]   =  head_SET_02[1]     ;
                      head_ROTATE_FRAMEA[2]   =  head_SET_02[2]     ; 
                   
                if(SelectionCount_HEAD == 2)
                {         
                     
                      head_ROTATE_FRAMEB[3]   =  head_SET_01[3]     ;
                      head_ROTATE_FRAMEB[0]   =  head_SET_01[0]     ;
                      head_ROTATE_FRAMEB[1]   =  head_SET_01[1]     ;
                      head_ROTATE_FRAMEB[2]   =  head_SET_01[2]     ;          
                }
                else
                {         
                      head_ROTATE_FRAMEB[3]   =  head_SET_03[3]     ;
                      head_ROTATE_FRAMEB[0]   =  head_SET_03[0]     ;
                      head_ROTATE_FRAMEB[1]   =  head_SET_03[1]     ;
                      head_ROTATE_FRAMEB[2]   =  head_SET_03[2]     ;          
                }
       }    
