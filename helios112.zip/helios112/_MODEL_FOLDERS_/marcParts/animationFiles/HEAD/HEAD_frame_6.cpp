if(setSelection_HEAD == 6)
{        
       head_ROTATE_FRAMEA[3]   =  head_SET_06[3]     ;
       head_ROTATE_FRAMEA[0]   =  head_SET_06[0]     ;
       head_ROTATE_FRAMEA[1]   =  head_SET_06[1]     ;
       head_ROTATE_FRAMEA[2]   =  head_SET_06[2]     ;          
              
              if(SelectionCount_HEAD == 6)         
              {
                      head_ROTATE_FRAMEB[3]   =  head_SET_01[3]     ;
                      head_ROTATE_FRAMEB[0]   =  head_SET_01[0]     ;
                      head_ROTATE_FRAMEB[1]   =  head_SET_01[1]     ;
                      head_ROTATE_FRAMEB[2]   =  head_SET_01[2]     ;          
              }
              else
              {             
                      head_ROTATE_FRAMEB[3]   =  head_SET_07[3]     ;
                      head_ROTATE_FRAMEB[0]   =  head_SET_07[0]     ;
                      head_ROTATE_FRAMEB[1]   =  head_SET_07[1]     ;
                      head_ROTATE_FRAMEB[2]   =  head_SET_07[2]     ;          
              }
}
