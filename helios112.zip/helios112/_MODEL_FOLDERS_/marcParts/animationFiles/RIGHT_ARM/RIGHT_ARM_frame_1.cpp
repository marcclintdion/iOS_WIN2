if(setSelection_RIGHT_ARM == 1)
{          
                      rightArmUpper_ROTATE_FRAMEA[3]   =  rightArmUpper_SET_01[3]     ;
                      rightArmUpper_ROTATE_FRAMEA[0]   =  rightArmUpper_SET_01[0]     ;
                      rightArmUpper_ROTATE_FRAMEA[1]   =  rightArmUpper_SET_01[1]     ;
                      rightArmUpper_ROTATE_FRAMEA[2]   =  rightArmUpper_SET_01[2]     ;
                 
                      rightArmUpper_ROTATE_FRAMEB[3]   =  rightArmUpper_SET_02[3]     ;
                      rightArmUpper_ROTATE_FRAMEB[0]   =  rightArmUpper_SET_02[0]     ;
                      rightArmUpper_ROTATE_FRAMEB[1]   =  rightArmUpper_SET_02[1]     ;
                      rightArmUpper_ROTATE_FRAMEB[2]   =  rightArmUpper_SET_02[2]     ;
                      ///_<subPart>_////                  
                      rightForeArm_ROTATE_FRAMEA[3]   =  rightForeArm_SET_01[3]     ;
                      rightForeArm_ROTATE_FRAMEA[0]   =  rightForeArm_SET_01[0]     ;
                      rightForeArm_ROTATE_FRAMEA[1]   =  rightForeArm_SET_01[1]     ;
                      rightForeArm_ROTATE_FRAMEA[2]   =  rightForeArm_SET_01[2]     ;
                 
                      rightForeArm_ROTATE_FRAMEB[3]   =  rightForeArm_SET_02[3]     ;
                      rightForeArm_ROTATE_FRAMEB[0]   =  rightForeArm_SET_02[0]     ;
                      rightForeArm_ROTATE_FRAMEB[1]   =  rightForeArm_SET_02[1]     ;
                      rightForeArm_ROTATE_FRAMEB[2]   =  rightForeArm_SET_02[2]     ;                           
                      ///_<subPart>_////           
                      rightGlovedHand_ROTATE_FRAMEA[3]   =  rightGlovedHand_SET_01[3]     ;
                      rightGlovedHand_ROTATE_FRAMEA[0]   =  rightGlovedHand_SET_01[0]     ;
                      rightGlovedHand_ROTATE_FRAMEA[1]   =  rightGlovedHand_SET_01[1]     ;
                      rightGlovedHand_ROTATE_FRAMEA[2]   =  rightGlovedHand_SET_01[2]     ;
                 
                      rightGlovedHand_ROTATE_FRAMEB[3]   =  rightGlovedHand_SET_02[3]     ;
                      rightGlovedHand_ROTATE_FRAMEB[0]   =  rightGlovedHand_SET_02[0]     ;
                      rightGlovedHand_ROTATE_FRAMEB[1]   =  rightGlovedHand_SET_02[1]     ;
                      rightGlovedHand_ROTATE_FRAMEB[2]   =  rightGlovedHand_SET_02[2]     ;         
}
