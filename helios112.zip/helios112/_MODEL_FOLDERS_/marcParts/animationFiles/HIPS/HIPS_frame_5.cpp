//int    setSelection_HIPS           = 1;
//int    SelectionCount_HIPS         = 0;


if(setSelection_HIPS == 5)
{
       hips_ROTATE_FRAMEA[3]   =  hips_SET_05[3]     ;
       hips_ROTATE_FRAMEA[0]   =  hips_SET_05[0]     ;
       hips_ROTATE_FRAMEA[1]   =  hips_SET_05[1]     ;
       hips_ROTATE_FRAMEA[2]   =  hips_SET_05[2]     ;


                if(SelectionCount_HIPS == 5)         
                {
                      hips_ROTATE_FRAMEB[3]   =  hips_SET_01[3]     ;
                      hips_ROTATE_FRAMEB[0]   =  hips_SET_01[0]     ;
                      hips_ROTATE_FRAMEB[1]   =  hips_SET_01[1]     ;
                      hips_ROTATE_FRAMEB[2]   =  hips_SET_01[2]     ;
                }
                else
                {               
           
                      hips_ROTATE_FRAMEB[3]   =  hips_SET_06[3]     ;
                      hips_ROTATE_FRAMEB[0]   =  hips_SET_06[0]     ;
                      hips_ROTATE_FRAMEB[1]   =  hips_SET_06[1]     ;
                      hips_ROTATE_FRAMEB[2]   =  hips_SET_06[2]     ;
                } 
} 
