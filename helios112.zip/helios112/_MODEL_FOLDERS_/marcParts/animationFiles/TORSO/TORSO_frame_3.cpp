//setSelection_TORSO          = 1;
//SelectionCount_TORSO        = 0;

if(setSelection_TORSO == 3)
{
      torso_ROTATE_FRAMEA[3]   =  torso_SET_03[3]     ;
      torso_ROTATE_FRAMEA[0]   =  torso_SET_03[0]     ;
      torso_ROTATE_FRAMEA[1]   =  torso_SET_03[1]     ;
      torso_ROTATE_FRAMEA[2]   =  torso_SET_03[2]     ;
       
           
                if(SelectionCount_TORSO == 3)
                {          
                      torso_ROTATE_FRAMEB[3]   =  torso_SET_01[3]     ;
                      torso_ROTATE_FRAMEB[0]   =  torso_SET_01[0]     ;
                      torso_ROTATE_FRAMEB[1]   =  torso_SET_01[1]     ;
                      torso_ROTATE_FRAMEB[2]   =  torso_SET_01[2]     ;
                }
                else
                {
                      torso_ROTATE_FRAMEB[3]   =  torso_SET_04[3]     ;
                      torso_ROTATE_FRAMEB[0]   =  torso_SET_04[0]     ;
                      torso_ROTATE_FRAMEB[1]   =  torso_SET_04[1]     ;
                      torso_ROTATE_FRAMEB[2]   =  torso_SET_04[2]     ;
                } 
}    
