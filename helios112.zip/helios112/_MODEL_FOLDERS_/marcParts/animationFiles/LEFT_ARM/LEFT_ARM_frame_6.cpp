           if(setSelection_LEFT_ARM == 6)
           {        

                      
                      leftUpperArm_ROTATE_FRAMEA[3]   =   leftUpperArm_SET_06[3]     ;
                      leftUpperArm_ROTATE_FRAMEA[0]   =   leftUpperArm_SET_06[0]     ;
                      leftUpperArm_ROTATE_FRAMEA[1]   =   leftUpperArm_SET_06[1]     ;
                      leftUpperArm_ROTATE_FRAMEA[2]   =   leftUpperArm_SET_06[2]     ;
         
                      leftForeArm_ROTATE_FRAMEA[3]   =    leftForeArm_SET_06[3]     ;
                      leftForeArm_ROTATE_FRAMEA[0]   =    leftForeArm_SET_06[0]     ;
                      leftForeArm_ROTATE_FRAMEA[1]   =    leftForeArm_SET_06[1]     ;
                      leftForeArm_ROTATE_FRAMEA[2]   =    leftForeArm_SET_06[2]     ;         
         
                      leftGlovedHand_ROTATE_FRAMEA[3]   =    leftGlovedHand_SET_06[3]     ;
                      leftGlovedHand_ROTATE_FRAMEA[0]   =    leftGlovedHand_SET_06[0]     ;
                      leftGlovedHand_ROTATE_FRAMEA[1]   =    leftGlovedHand_SET_06[1]     ;
                      leftGlovedHand_ROTATE_FRAMEA[2]   =    leftGlovedHand_SET_06[2]     ;
                         


          
              


              
              if(SelectionCount_LEFT_ARM == 6)         
              {
                                  
                              
                               
                                  leftUpperArm_ROTATE_FRAMEB[3]   =    leftUpperArm_SET_01[3]     ;
                                  leftUpperArm_ROTATE_FRAMEB[0]   =    leftUpperArm_SET_01[0]     ;
                                  leftUpperArm_ROTATE_FRAMEB[1]   =    leftUpperArm_SET_01[1]     ;
                                  leftUpperArm_ROTATE_FRAMEB[2]   =    leftUpperArm_SET_01[2]     ;          
          
                                  leftForeArm_ROTATE_FRAMEB[3]   =   leftForeArm_SET_01[3]     ;
                                  leftForeArm_ROTATE_FRAMEB[0]   =   leftForeArm_SET_01[0]     ;
                                  leftForeArm_ROTATE_FRAMEB[1]   =   leftForeArm_SET_01[1]     ;
                                  leftForeArm_ROTATE_FRAMEB[2]   =   leftForeArm_SET_01[2]     ;          
          
                                  leftGlovedHand_ROTATE_FRAMEB[3]   =    leftGlovedHand_SET_01[3]     ;
                                  leftGlovedHand_ROTATE_FRAMEB[0]   =    leftGlovedHand_SET_01[0]     ;
                                  leftGlovedHand_ROTATE_FRAMEB[1]   =    leftGlovedHand_SET_01[1]     ;
                                  leftGlovedHand_ROTATE_FRAMEB[2]   =    leftGlovedHand_SET_01[2]     ;



        
        
              }

                                          
              
                else
                {             
                                           
                         
                                  leftUpperArm_ROTATE_FRAMEB[3]   =    leftUpperArm_SET_07[3]     ;
                                  leftUpperArm_ROTATE_FRAMEB[0]   =    leftUpperArm_SET_07[0]     ;
                                  leftUpperArm_ROTATE_FRAMEB[1]   =    leftUpperArm_SET_07[1]     ;
                                  leftUpperArm_ROTATE_FRAMEB[2]   =    leftUpperArm_SET_07[2]     ;          
                         
                                  leftForeArm_ROTATE_FRAMEB[3]   =    leftForeArm_SET_07[3]     ;
                                  leftForeArm_ROTATE_FRAMEB[0]   =    leftForeArm_SET_07[0]     ;
                                  leftForeArm_ROTATE_FRAMEB[1]   =    leftForeArm_SET_07[1]     ;
                                  leftForeArm_ROTATE_FRAMEB[2]   =    leftForeArm_SET_07[2]     ;           
         
                                  leftGlovedHand_ROTATE_FRAMEB[3]   =  leftGlovedHand_SET_07[3]     ;
                                  leftGlovedHand_ROTATE_FRAMEB[0]   =  leftGlovedHand_SET_07[0]     ;
                                  leftGlovedHand_ROTATE_FRAMEB[1]   =  leftGlovedHand_SET_07[1]     ;
                                  leftGlovedHand_ROTATE_FRAMEB[2]   =  leftGlovedHand_SET_07[2]     ;



          
           }
}
