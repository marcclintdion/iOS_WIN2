        if(setSelection_LEFT_ARM == 1)
         {          

                      leftUpperArm_ROTATE_FRAMEA[3]    =  leftUpperArm_SET_01[3];
                      leftUpperArm_ROTATE_FRAMEA[0]    =  leftUpperArm_SET_01[0];
                      leftUpperArm_ROTATE_FRAMEA[1]    =  leftUpperArm_SET_01[1];
                      leftUpperArm_ROTATE_FRAMEA[2]    =  leftUpperArm_SET_01[2];
                 
                      leftUpperArm_ROTATE_FRAMEB[3]    =  leftUpperArm_SET_02[3];
                      leftUpperArm_ROTATE_FRAMEB[0]    =  leftUpperArm_SET_02[0];
                      leftUpperArm_ROTATE_FRAMEB[1]    =  leftUpperArm_SET_02[1]     ;
                      leftUpperArm_ROTATE_FRAMEB[2]    =  leftUpperArm_SET_02[2]     ;
                      ///_<subPart>_////                 
                      leftForeArm_ROTATE_FRAMEA[3]     =  leftForeArm_SET_01[3]     ;
                      leftForeArm_ROTATE_FRAMEA[0]     =  leftForeArm_SET_01[0]     ;
                      leftForeArm_ROTATE_FRAMEA[1]     =  leftForeArm_SET_01[1]     ;
                      leftForeArm_ROTATE_FRAMEA[2]     =  leftForeArm_SET_01[2]     ;
                 
                      leftForeArm_ROTATE_FRAMEB[3]     =  leftForeArm_SET_02[3]     ;
                      leftForeArm_ROTATE_FRAMEB[0]     =  leftForeArm_SET_02[0]     ;
                      leftForeArm_ROTATE_FRAMEB[1]     =  leftForeArm_SET_02[1]     ;
                      leftForeArm_ROTATE_FRAMEB[2]     =  leftForeArm_SET_02[2]     ;                           
                      ///_<subPart>_////          
                      leftGlovedHand_ROTATE_FRAMEA[3]  =  leftGlovedHand_SET_01[3]     ;
                      leftGlovedHand_ROTATE_FRAMEA[0]  =  leftGlovedHand_SET_01[0]     ;
                      leftGlovedHand_ROTATE_FRAMEA[1]  =  leftGlovedHand_SET_01[1]     ;
                      leftGlovedHand_ROTATE_FRAMEA[2]  =  leftGlovedHand_SET_01[2]     ;
                 
                      leftGlovedHand_ROTATE_FRAMEB[3]  =  leftGlovedHand_SET_02[3]     ;
                      leftGlovedHand_ROTATE_FRAMEB[0]  =  leftGlovedHand_SET_02[0]     ;
                      leftGlovedHand_ROTATE_FRAMEB[1]  =  leftGlovedHand_SET_02[1]     ;
                      leftGlovedHand_ROTATE_FRAMEB[2]  =  leftGlovedHand_SET_02[2]     ;            
         
       

       

         
          }
