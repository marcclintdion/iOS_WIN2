if(setSelection_RIGHT_LEG == 5)
{
                      rightUpperLeg_ROTATE_FRAMEA[3]   =    rightUpperLeg_SET_05[3]     ;
                      rightUpperLeg_ROTATE_FRAMEA[0]   =    rightUpperLeg_SET_05[0]     ;
                      rightUpperLeg_ROTATE_FRAMEA[1]   =    rightUpperLeg_SET_05[1]     ;
                      rightUpperLeg_ROTATE_FRAMEA[2]   =    rightUpperLeg_SET_05[2]     ;
                 
                      rightLowerLeg_ROTATE_FRAMEA[3]   =    rightLowerLeg_SET_05[3]     ;
                      rightLowerLeg_ROTATE_FRAMEA[0]   =    rightLowerLeg_SET_05[0]     ;
                      rightLowerLeg_ROTATE_FRAMEA[1]   =    rightLowerLeg_SET_05[1]     ;
                      rightLowerLeg_ROTATE_FRAMEA[2]   =    rightLowerLeg_SET_05[2]     ;          
         
                      rightFoot_ROTATE_FRAMEA[3]   =    rightFoot_SET_05[3]     ;
                      rightFoot_ROTATE_FRAMEA[0]   =    rightFoot_SET_05[0]     ;
                      rightFoot_ROTATE_FRAMEA[1]   =    rightFoot_SET_05[1]     ;
                      rightFoot_ROTATE_FRAMEA[2]   =    rightFoot_SET_05[2]     ; 

                      if(SelectionCount_RIGHT_LEG == 5)         
                      {
                                  rightUpperLeg_ROTATE_FRAMEB[3]   =  rightUpperLeg_SET_01[3]     ;
                                  rightUpperLeg_ROTATE_FRAMEB[0]   =  rightUpperLeg_SET_01[0]     ;
                                  rightUpperLeg_ROTATE_FRAMEB[1]   =  rightUpperLeg_SET_01[1]     ;
                                  rightUpperLeg_ROTATE_FRAMEB[2]   =  rightUpperLeg_SET_01[2]     ;           
                                  
                                  rightLowerLeg_ROTATE_FRAMEB[3]   =  rightLowerLeg_SET_01[3]     ;
                                  rightLowerLeg_ROTATE_FRAMEB[0]   =  rightLowerLeg_SET_01[0]     ;
                                  rightLowerLeg_ROTATE_FRAMEB[1]   =  rightLowerLeg_SET_01[1]     ;
                                  rightLowerLeg_ROTATE_FRAMEB[2]   =  rightLowerLeg_SET_01[2]     ;          
          
                                  rightFoot_ROTATE_FRAMEB[3]   =   rightFoot_SET_01[3]     ;
                                  rightFoot_ROTATE_FRAMEB[0]   =   rightFoot_SET_01[0]     ;
                                  rightFoot_ROTATE_FRAMEB[1]   =   rightFoot_SET_01[1]     ;
                                  rightFoot_ROTATE_FRAMEB[2]   =   rightFoot_SET_01[2]     ;
                      }
                      else
                      {               
                                  rightUpperLeg_ROTATE_FRAMEB[3]   =  rightUpperLeg_SET_06[3]     ;
                                  rightUpperLeg_ROTATE_FRAMEB[0]   =  rightUpperLeg_SET_06[0]     ;
                                  rightUpperLeg_ROTATE_FRAMEB[1]   =  rightUpperLeg_SET_06[1]     ;
                                  rightUpperLeg_ROTATE_FRAMEB[2]   =  rightUpperLeg_SET_06[2]     ;          
                             
                                  rightLowerLeg_ROTATE_FRAMEB[3]   =  rightLowerLeg_SET_06[3]     ;
                                  rightLowerLeg_ROTATE_FRAMEB[0]   =  rightLowerLeg_SET_06[0]     ;
                                  rightLowerLeg_ROTATE_FRAMEB[1]   =  rightLowerLeg_SET_06[1]     ;
                                  rightLowerLeg_ROTATE_FRAMEB[2]   =  rightLowerLeg_SET_06[2]     ;                 
          
                                  rightFoot_ROTATE_FRAMEB[3]   =   rightFoot_SET_06[3]         ;
                                  rightFoot_ROTATE_FRAMEB[0]   =   rightFoot_SET_06[0]         ;
                                  rightFoot_ROTATE_FRAMEB[1]   =   rightFoot_SET_06[1]         ;
                                  rightFoot_ROTATE_FRAMEB[2]   =   rightFoot_SET_06[2]         ; 
                        } 
} 
