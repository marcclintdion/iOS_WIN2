if(setSelection_RIGHT_LEG == 1)
{          
                      rightUpperLeg_ROTATE_FRAMEA[3]   =  rightUpperLeg_SET_01[3]     ;
                      rightUpperLeg_ROTATE_FRAMEA[0]   =  rightUpperLeg_SET_01[0]     ;
                      rightUpperLeg_ROTATE_FRAMEA[1]   =  rightUpperLeg_SET_01[1]     ;
                      rightUpperLeg_ROTATE_FRAMEA[2]   =  rightUpperLeg_SET_01[2]     ;
                 
                      rightUpperLeg_ROTATE_FRAMEB[3]   =  rightUpperLeg_SET_02[3]     ;
                      rightUpperLeg_ROTATE_FRAMEB[0]   =  rightUpperLeg_SET_02[0]     ;
                      rightUpperLeg_ROTATE_FRAMEB[1]   =  rightUpperLeg_SET_02[1]     ;
                      rightUpperLeg_ROTATE_FRAMEB[2]   =  rightUpperLeg_SET_02[2]     ;
                      ///_<subPart>_////                  
                      rightLowerLeg_ROTATE_FRAMEA[3]   =  rightLowerLeg_SET_01[3]     ;
                      rightLowerLeg_ROTATE_FRAMEA[0]   =  rightLowerLeg_SET_01[0]     ;
                      rightLowerLeg_ROTATE_FRAMEA[1]   =  rightLowerLeg_SET_01[1]     ;
                      rightLowerLeg_ROTATE_FRAMEA[2]   =  rightLowerLeg_SET_01[2]     ;
                 
                      rightLowerLeg_ROTATE_FRAMEB[3]   =  rightLowerLeg_SET_02[3]     ;
                      rightLowerLeg_ROTATE_FRAMEB[0]   =  rightLowerLeg_SET_02[0]     ;
                      rightLowerLeg_ROTATE_FRAMEB[1]   =  rightLowerLeg_SET_02[1]     ;
                      rightLowerLeg_ROTATE_FRAMEB[2]   =  rightLowerLeg_SET_02[2]     ;                           
                      ///_<subPart>_////          
                      rightFoot_ROTATE_FRAMEA[3]   =  rightFoot_SET_01[3]     ;
                      rightFoot_ROTATE_FRAMEA[0]   =  rightFoot_SET_01[0]     ;
                      rightFoot_ROTATE_FRAMEA[1]   =  rightFoot_SET_01[1]     ;
                      rightFoot_ROTATE_FRAMEA[2]   =  rightFoot_SET_01[2]     ;
                 
                      rightFoot_ROTATE_FRAMEB[3]   =  rightFoot_SET_02[3]     ;
                      rightFoot_ROTATE_FRAMEB[0]   =  rightFoot_SET_02[0]     ;
                      rightFoot_ROTATE_FRAMEB[1]   =  rightFoot_SET_02[1]     ;
                      rightFoot_ROTATE_FRAMEB[2]   =  rightFoot_SET_02[2]     ;          
}
