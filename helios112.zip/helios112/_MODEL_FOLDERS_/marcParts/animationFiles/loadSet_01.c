           mainBodyPosition[0]           = mainBodyPosition_SET_01[0] ;
           mainBodyPosition[1]           = mainBodyPosition_SET_01[1]   ;           
           mainBodyPosition[2]           = mainBodyPosition_SET_01[2]   ;            
           
           leftUpperArm_ROTATE[3]    = leftUpperArm_SET_01[3]  ;
           leftUpperArm_ROTATE[0]    = leftUpperArm_SET_01[0]  ;
           leftUpperArm_ROTATE[1]    = leftUpperArm_SET_01[1]  ;
           leftUpperArm_ROTATE[2]    = leftUpperArm_SET_01[2]  ;
           
           leftForeArm_ROTATE[3]     = leftForeArm_SET_01[3]   ;
           leftForeArm_ROTATE[0]     = leftForeArm_SET_01[0]   ;
           leftForeArm_ROTATE[1]     = leftForeArm_SET_01[1]   ;
           leftForeArm_ROTATE[2]     = leftForeArm_SET_01[2]   ;
           
           leftGlovedHand_ROTATE[3]  =   leftGlovedHand_SET_01[3]    ;
           leftGlovedHand_ROTATE[0]  =  leftGlovedHand_SET_01[0]    ;
           leftGlovedHand_ROTATE[1]  =  leftGlovedHand_SET_01[1]    ;
           leftGlovedHand_ROTATE[2]  =  leftGlovedHand_SET_01[2]    ;
           ///_<switchPart>_//////////////////////////////////////////////////////////////////////////////////////////////////////____<switchPart>           
           rightUpperArm_ROTATE[3]   =  rightUpperArm_SET_01[3]  ;
           rightUpperArm_ROTATE[0]   =  rightUpperArm_SET_01[0]  ;
           rightUpperArm_ROTATE[1]   =  rightUpperArm_SET_01[1]  ;
           rightUpperArm_ROTATE[2]   = rightUpperArm_SET_01[2]   ;
           
           rightForeArm_ROTATE[3]    =  rightForeArm_SET_01[3]    ;
           rightForeArm_ROTATE[0]    =  rightForeArm_SET_01[0]    ;
           rightForeArm_ROTATE[1]    =  rightForeArm_SET_01[1]    ;
           rightForeArm_ROTATE[2]    =  rightForeArm_SET_01[2]    ;
           
           rightGlovedHand_ROTATE[3] =  rightGlovedHand_SET_01[3]    ;
           rightGlovedHand_ROTATE[0] =  rightGlovedHand_SET_01[0]    ;
           rightGlovedHand_ROTATE[1] =  rightGlovedHand_SET_01[1]    ;
           rightGlovedHand_ROTATE[2] =  rightGlovedHand_SET_01[2]    ;
           ///_<switchPart>_//////////////////////////////////////////////////////////////////////////////////////////////////////____<switchPart>           
           leftUpperLeg_ROTATE[3]    =  leftUpperLeg_SET_01[3]   ;
           leftUpperLeg_ROTATE[0]    =  leftUpperLeg_SET_01[0]   ;
           leftUpperLeg_ROTATE[1]    =  leftUpperLeg_SET_01[1]   ;
           leftUpperLeg_ROTATE[2]    =  leftUpperLeg_SET_01[2]   ;
           
           leftLowerLeg_ROTATE[3]    =  leftLowerLeg_SET_01[3]    ;
           leftLowerLeg_ROTATE[0]    =  leftLowerLeg_SET_01[0]    ;
           leftLowerLeg_ROTATE[1]    =  leftLowerLeg_SET_01[1]    ;
           leftLowerLeg_ROTATE[2]    =  leftLowerLeg_SET_01[2]    ;
           
           leftFoot_ROTATE[3]        =  leftFoot_SET_01[3]   ;
           leftFoot_ROTATE[0]        =  leftFoot_SET_01[0]    ;
           leftFoot_ROTATE[1]        =  leftFoot_SET_01[1]    ;
           leftFoot_ROTATE[2]        =  leftFoot_SET_01[2]    ;                                             
           ///_<switchPart>_//////////////////////////////////////////////////////////////////////////////////////////////////////____<switchPart>           
           rightUpperLeg_ROTATE[3]   =  rightUpperLeg_SET_01[3]  ;
           rightUpperLeg_ROTATE[0]   =  rightUpperLeg_SET_01[0]   ;
           rightUpperLeg_ROTATE[1]   =  rightUpperLeg_SET_01[1]   ;
           rightUpperLeg_ROTATE[2]   =  rightUpperLeg_SET_01[2]   ;
           
           rightLowerLeg_ROTATE[3]   =  rightLowerLeg_SET_01[3]    ;
           rightLowerLeg_ROTATE[0]   =  rightLowerLeg_SET_01[0]    ;
           rightLowerLeg_ROTATE[1]   =  rightLowerLeg_SET_01[1]    ;
           rightLowerLeg_ROTATE[2]   =  rightLowerLeg_SET_01[2]    ;
           
           rightFoot_ROTATE[3]       =  rightFoot_SET_01[3]   ;
           rightFoot_ROTATE[0]       =  rightFoot_SET_01[0]   ;
           rightFoot_ROTATE[1]       =  rightFoot_SET_01[1]   ;
           rightFoot_ROTATE[2]       =  rightFoot_SET_01[2]   ;
           ///_<switchPart>_//////////////////////////////////////////////////////////////////////////////////////////////////////____<switchPart>           

           hips_ROTATE[3]            =  hips_SET_01[3]   ;
           hips_ROTATE[0]            =  hips_SET_01[0]    ;
           hips_ROTATE[1]            =  hips_SET_01[1]   ;
           hips_ROTATE[2]            =  hips_SET_01[2]    ;
           ///_<switchPart>_//////////////////////////////////////////////////////////////////////////////////////////////////////____<switchPart>                         
           torso_ROTATE[3]           = torso_SET_01[3]   ;
           torso_ROTATE[0]           = torso_SET_01[0]    ;
           torso_ROTATE[1]           = torso_SET_01[1]   ;
           torso_ROTATE[2]           = torso_SET_01[2]   ;
           ///_<switchPart>_//////////////////////////////////////////////////////////////////////////////////////////////////////____<switchPart>
           head_ROTATE[3]            = head_SET_01[3]   ;
           head_ROTATE[0]            = head_SET_01[0]    ;
           head_ROTATE[1]            = head_SET_01[1]    ;
           head_ROTATE[2]            = head_SET_01[2]    ;
