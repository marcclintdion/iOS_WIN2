           if(setSelection_LEFT_LEG == 2)
           {
                      leftUpperLeg_ROTATE_FRAMEA[3]   =  leftUpperLeg_SET_02[3]     ;
                      leftUpperLeg_ROTATE_FRAMEA[0]   =  leftUpperLeg_SET_02[0]     ;
                      leftUpperLeg_ROTATE_FRAMEA[1]   =  leftUpperLeg_SET_02[1]     ;
                      leftUpperLeg_ROTATE_FRAMEA[2]   =  leftUpperLeg_SET_02[2]     ;
                      ///_<subPart>_////  
                      leftLowerLeg_ROTATE_FRAMEA[3]   =  leftLowerLeg_SET_02[3]     ;
                      leftLowerLeg_ROTATE_FRAMEA[0]   =  leftLowerLeg_SET_02[0]     ;
                      leftLowerLeg_ROTATE_FRAMEA[1]   =  leftLowerLeg_SET_02[1]     ;
                      leftLowerLeg_ROTATE_FRAMEA[2]   =  leftLowerLeg_SET_02[2]     ;                 
                      ///_<subPart>_////   
                      leftFoot_ROTATE_FRAMEA[3]   =  leftFoot_SET_02[3]     ;
                      leftFoot_ROTATE_FRAMEA[0]   =  leftFoot_SET_02[0]     ;
                      leftFoot_ROTATE_FRAMEA[1]   =  leftFoot_SET_02[1]     ;
                      leftFoot_ROTATE_FRAMEA[2]   =  leftFoot_SET_02[2]     ;          
           
             if(SelectionCount_LEFT_LEG == 2)
             {         
                                  leftUpperLeg_ROTATE_FRAMEB[3]   =  leftUpperLeg_SET_01[3]     ;
                                  leftUpperLeg_ROTATE_FRAMEB[0]   =  leftUpperLeg_SET_01[0]     ;
                                  leftUpperLeg_ROTATE_FRAMEB[1]   =  leftUpperLeg_SET_01[1]     ;
                                  leftUpperLeg_ROTATE_FRAMEB[2]   =  leftUpperLeg_SET_01[2]     ;           
                                      ///_<subPart>_//// 
                                  leftLowerLeg_ROTATE_FRAMEB[3]   =  leftLowerLeg_SET_01[3]     ;
                                  leftLowerLeg_ROTATE_FRAMEB[0]   =  leftLowerLeg_SET_01[0]     ;
                                  leftLowerLeg_ROTATE_FRAMEB[1]   =  leftLowerLeg_SET_01[1]     ;
                                  leftLowerLeg_ROTATE_FRAMEB[2]   =  leftLowerLeg_SET_01[2]     ;         
                                  ///_<subPart>_//// 
                                  leftFoot_ROTATE_FRAMEB[3]   =  leftFoot_SET_01[3]     ;
                                  leftFoot_ROTATE_FRAMEB[0]   =  leftFoot_SET_01[0]     ;
                                  leftFoot_ROTATE_FRAMEB[1]   =  leftFoot_SET_01[1]     ;
                                  leftFoot_ROTATE_FRAMEB[2]   =  leftFoot_SET_01[2]      ;          
             }
             else
             {         
                                  leftUpperLeg_ROTATE_FRAMEB[3]   =  leftUpperLeg_SET_03[3]     ;
                                  leftUpperLeg_ROTATE_FRAMEB[0]   =  leftUpperLeg_SET_03[0]     ;
                                  leftUpperLeg_ROTATE_FRAMEB[1]   =  leftUpperLeg_SET_03[1]     ;
                                  leftUpperLeg_ROTATE_FRAMEB[2]   =  leftUpperLeg_SET_03[2]     ;          
                                        ///_<subPart>_////                             
                                  leftLowerLeg_ROTATE_FRAMEB[3]   =  leftLowerLeg_SET_03[3]     ;
                                  leftLowerLeg_ROTATE_FRAMEB[0]   =  leftLowerLeg_SET_03[0]     ;
                                  leftLowerLeg_ROTATE_FRAMEB[1]   =  leftLowerLeg_SET_03[1]     ;
                                  leftLowerLeg_ROTATE_FRAMEB[2]   =  leftLowerLeg_SET_03[2]     ;                          
                                  ///_<subPart>_////           
                                  leftFoot_ROTATE_FRAMEB[3]   =  leftFoot_SET_03[3]     ;
                                  leftFoot_ROTATE_FRAMEB[0]   =  leftFoot_SET_03[0]     ;
                                  leftFoot_ROTATE_FRAMEB[1]   =  leftFoot_SET_03[1]     ;
                                  leftFoot_ROTATE_FRAMEB[2]   =  leftFoot_SET_03[2]     ;          
            }
}    
 
