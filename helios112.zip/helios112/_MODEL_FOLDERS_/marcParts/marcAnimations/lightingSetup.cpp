
                   
                   


   float hips_light[] = {12.913, 100, -149.049};
   GLfloat quadraticAttenuationhips =   1.17003;
   
   GLint   uniformLightPosition;   
   GLint   uniformLightAttenuation;
   GLfloat nMapLightPosition[]     = {12.913, 100, -149.049};
   GLfloat nMapLightAttenuation  = 3.5005e-005;

   

