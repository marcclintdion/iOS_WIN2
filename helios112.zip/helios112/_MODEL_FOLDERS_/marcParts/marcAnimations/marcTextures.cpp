loadTexture("marcAnimations/MARC_PARTS/newface.jpg",            marcTextures[1]);      
loadTexture("marcAnimations/MARC_PARTS/newfaceDOT3.jpg",        marcNormals[1]);

loadTexture("marcAnimations/MARC_PARTS/headBack.jpg",           marcTextures[4]);          
loadTexture("marcAnimations/MARC_PARTS/headBack_DOT3.jpg",      marcNormals[4]);

loadTexture("marcAnimations/MARC_PARTS/leftUpperArmWood.jpg",   marcTextures[2]);  
loadTexture("marcAnimations/MARC_PARTS/leftUpperArm_DOT3.jpg",  marcNormals[2]);

loadTexture("marcAnimations/MARC_PARTS/leftForeArmWood.jpg",    marcTextures[3]);
loadTexture("marcAnimations/MARC_PARTS/leftForeArm_DOT3.jpg",   marcNormals[3]);

loadTexture("marcAnimations/MARC_PARTS/rightUpperArmWood.jpg",  marcTextures[5]);
loadTexture("marcAnimations/MARC_PARTS/rightUpperArm_DOT3.jpg", marcNormals[5]);

loadTexture("marcAnimations/MARC_PARTS/rightForeArmWood.jpg",   marcTextures[6]);
loadTexture("marcAnimations/MARC_PARTS/rightForeArm_DOT3.jpg",  marcNormals[6]);

loadTexture("marcAnimations/MARC_PARTS/torsoWood.jpg",          marcTextures[7]);
loadTexture("marcAnimations/MARC_PARTS/torsoWood_DOT3.jpg",     marcNormals[7]);

loadTexture("marcAnimations/MARC_PARTS/hips.jpg",               marcTextures[8]);
loadTexture("marcAnimations/MARC_PARTS/hips_DOT3.jpg",          marcNormals[8]);

loadTexture("marcAnimations/MARC_PARTS/leftUpperLeg.jpg",       marcTextures[9]);
loadTexture("marcAnimations/MARC_PARTS/leftUpperLeg_DOT3.jpg",  marcNormals[9]);

loadTexture("marcAnimations/MARC_PARTS/leftLowerLeg.jpg",       marcTextures[10]);
loadTexture("marcAnimations/MARC_PARTS/leftLowerLeg_DOT3.jpg",  marcNormals[10]);

loadTexture("marcAnimations/MARC_PARTS/leftBoot.jpg",           marcTextures[11]);
loadTexture("marcAnimations/MARC_PARTS/leftBoot_DOT3.jpg",      marcNormals[11]);

loadTexture("marcAnimations/MARC_PARTS/rightUpperLeg.jpg",      marcTextures[12]);
loadTexture("marcAnimations/MARC_PARTS/rightUpperLeg_DOT3.jpg", marcNormals[12]);

loadTexture("marcAnimations/MARC_PARTS/rightLowerLeg.jpg",      marcTextures[13]);
loadTexture("marcAnimations/MARC_PARTS/rightLowerLeg_DOT3.jpg", marcNormals[13]);

loadTexture("marcAnimations/MARC_PARTS/rightBoot.jpg",          marcTextures[14]);
loadTexture("marcAnimations/MARC_PARTS/rightBoot_DOT3.jpg",     marcNormals[14]);

loadTexture("marcAnimations/MARC_PARTS/leftHand.jpg",           marcTextures[15]);
loadTexture("marcAnimations/MARC_PARTS/leftHand_DOT3.jpg",      marcNormals[15]);
 
loadTexture("marcAnimations/MARC_PARTS/rightHand.jpg",          marcTextures[16]);
loadTexture("marcAnimations/MARC_PARTS/rightHand_DOT3.jpg",     marcNormals[16]);
