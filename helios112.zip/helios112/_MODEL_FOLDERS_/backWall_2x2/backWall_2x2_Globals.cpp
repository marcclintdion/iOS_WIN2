GLfloat     backWall_2x2_POSITION[]        = { 0.0, 0.0, 0.0, 1.0};                                                                          
GLfloat     backWall_2x2_ROTATE[]          = { 1.0, 0.0,  0.0, 0.0};                                                                         
GLfloat     backWall_2x2_SCALE[]           = { 1.0, 0.0,  0.0, 0.0};                                                                         
//-----------------------------------------------------------------                                                                      
                                                                       
GLfloat     backWall_2x2_AMBIENT           = 0.0;                                                                                            
//-----------------------------------------------------------------                                                                      
GLuint      backWall_2x2_VBO;                                                                                                                
//-----------------------------------------------------------------                                                                      
GLuint      backWall_2x2_NORMAL_TEX;                                                                                                         
GLuint      backWall_2x2_TEXTURE1;                                                                                                           
