

      GLfloat     tile_2m_POSITION[]             =  { 0, 0.0, 0, 1.0};
      GLfloat     tile_2m_ROTATE[]               =  { 0.0, 1.0,  0.0, 0.0};
      //GLfloat     tile_2m_SCALE[]              =  { 1.0, 1.0,  1.0, 1.0};  
      //-----------------------------      
      GLuint      tile_2m_VBO;
      //-----------------------------
      GLuint      tile_2m_NORMAL_TEX;
      GLuint      tile_2m_TEXTURE1;
