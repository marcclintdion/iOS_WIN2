            glDeleteTextures( 1,    &spikyBall_0_TEXTURE1);                                                                             
            glDeleteTextures( 1,    &spikyBall_0_NORMAL_TEX);                                                                           
            glDeleteBuffersARB(1,   &spikyBall_0_VBO);                                                                                  
