GLfloat       spikyBall_0_POSITION[]                                    = {  0.5, 0.5, 0.5};                                                                       
                                GLfloat       spikyBall_0_ROTATE[]                                      = {  1.0, 0.0,  0.0, 0.0};                                                                         
                                GLfloat       spikyBall_0_SCALE                                         =    0.21;  
                                //------------
                                GLfloat       moveShadow_A_spikyBall_0[]                                = {  0.286, 0.0, -0.809998, 1.0};
                                GLfloat       moveShadow_B_spikyBall_0[]                                = {  0.286, 0.0, -0.809998, 1.0};
                                GLfloat       rotateShadow_SpikyBall[]                                  = {  1.0, 0.0, 0.0, 0.16};
                                GLfloat       scaleSpikeyBallShadowMove                                 =    0.00;
                                                                                                      
//-----------------------------------------------------------------                                                                      
GLfloat     spikyBall_0_LIGHT_POSITION[]  =  {0, 0, 10, 1};                                                                        
GLfloat     spikyBall_0_AMBIENT           = 0.0;                                                                                            
//-----------------------------------------------------------------                                                                      
GLuint      spikyBall_0_VBO;                                                                                                                
//-----------------------------------------------------------------                                                                      
GLuint      spikyBall_0_NORMAL_TEX;                                                                                                         
GLuint      spikyBall_0_TEXTURE1;                                                                                                           
