  GLfloat     head_LIGHT_POSITION_01[] = {2, -7.90002, 30, 1};
  GLfloat     head_ATTENUATION         =  0.94;
  GLfloat     head_SHININESS           =  80;
