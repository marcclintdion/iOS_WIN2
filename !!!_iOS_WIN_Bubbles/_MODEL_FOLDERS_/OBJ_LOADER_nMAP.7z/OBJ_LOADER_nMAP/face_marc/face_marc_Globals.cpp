GLuint      face_marc_SHADER_VERTEX;                                                                                                      
GLuint      face_marc_SHADER_FRAGMENT;                                                                                                    
GLuint      face_marc_SHADER;                                                                                                             
//--------------------------------------                                                                                                  
GLuint      UNIFORM_MODELVIEWPROJ_face_marc;                                                                                              
GLuint      UNIFORM_LIGHT_MATRIX_face_marc;                                                                                               
//--------------------------------------                                                                                                  
GLuint      UNIFORM_LIGHT_POSITION_01_face_marc;                                                                                          
GLuint      UNIFORM_SHININESS_face_marc;                                                                                                  
GLuint      UNIFORM_TEXTURE_DOT3_face_marc;                                                                                               
GLuint      UNIFORM_TEXTURE_face_marc;                                                                                                    
//--------------------------------------                                                                                                  
GLfloat     face_marc_POSITION[]            =  {  0.0, 0.0, 0.0, 1.0};                                                                    
GLfloat     face_marc_ROTATE[]              =  {  0.0, 1.0,  0.0, 0.0};                                                                   
GLfloat     face_marc_SCALE[]               =  {  1.0, 1.0,  1.0, 1.0};                                                                   
//-----------------------------------------------------------------                                                                       
GLfloat     face_marc_LIGHT_POSITION_01[]   =  {  2.0, 15.0, 30.0, 1.0};                                                                  
GLfloat     face_marc_SHININESS             =    80.0;                                                                                    
GLfloat     face_marc_ATTENUATION           =     1.0;                                                                                    
//-----------------------------------------------------------------                                                                       
GLuint      face_marc_VBO;                                                                                                                
//-----------------------------------------------------------------                                                                       
GLuint      face_marc_NORMALMAP;                                                                                                          
GLuint      face_marc_TEXTUREMAP;                                                                                                         
