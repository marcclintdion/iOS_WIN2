    //=======================================================================================                                           
    if (keys['J'])                                                                                                                      
    {                                                                                                                                   
             bubbles_POSITION[0]         -=  .01;                                                                                  
    }	                                                                                                                                  
    if (keys['L'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_POSITION[0]         +=  .01;                                                                                  
    }                                                                                                                                   
    if (keys['I'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_POSITION[1]         +=  .01;                                                                                  
    }	                                                                                                                                  
    if (keys['K'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_POSITION[1]         -=  .01;                                                                                  
    }                                                                                                                                   
    if (keys['O'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_POSITION[2]         +=  .01;                                                                                  
    }	                                                                                                                                  
    if (keys['U'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_POSITION[2]         -=  .01;                                                                                  
    }                                                                                                                                   
    //=======================================================================================                                           
    //=======================================================================================                                           
    /* if (keys['J'])                                                                                                                   
    {                                                                                                                                   
             bubbles_LIGHT_POSITION_01[0]         -=  .01;                                                                         
    }	                                                                                                                                  
    if (keys['L'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_LIGHT_POSITION_01[0]         +=  .01;                                                                         
    }                                                                                                                                   
    if (keys['I'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_LIGHT_POSITION_01[1]         +=  .01;                                                                         
    }	                                                                                                                                  
    if (keys['K'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_LIGHT_POSITION_01[1]         -=  .01;                                                                         
    }                                                                                                                                   
    if (keys['O'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_LIGHT_POSITION_01[2]         +=  .01;                                                                         
    }	                                                                                                                                  
    if (keys['U'])                                                                                                                      
    {	                                                                                                                                  
             bubbles_LIGHT_POSITION_01[2]         -=  .01;                                                                         
    } */                                                                                                                                
    //=======================================================================================                                           
